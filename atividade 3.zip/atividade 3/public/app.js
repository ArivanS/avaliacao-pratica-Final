const tabela = document.getElementById("tabela-contatos");
const form = document.getElementById("form");
const nomeInput = document.getElementById("nome");
const telefoneInput = document.getElementById("telefone");
const emailInput = document.getElementById("email");
const buscaInput = document.getElementById("busca");

const modal = document.getElementById("modal-editar");
const fecharModal = modal.querySelector(".fechar");
const formEditar = document.getElementById("form-editar");
const nomeEditar = document.getElementById("nome-editar");
const telefoneEditar = document.getElementById("telefone-editar");
const emailEditar = document.getElementById("email-editar");

let contatos = [];
let editandoId = null;

async function carregarContatos() {
  const resp = await fetch("/api/contatos");
  contatos = await resp.json();
  renderizarTabela(contatos);
}

function renderizarTabela(lista) {
  tabela.innerHTML = "";

  lista.forEach((contato, index) => {
    tabela.innerHTML += `
      <tr>
        <td>${index + 1}</td>
        <td>${contato.nome}</td>
        <td>${contato.telefone}</td>
        <td>${contato.email}</td>
        <td>
          <button class="editar" data-contato='${JSON.stringify(contato)}'>Editar</button>
          <button class="deletar" data-id='${contato.id}'>Excluir</button>
        </td>
      </tr>
    `;
  });

  document.querySelectorAll(".editar").forEach(btn => {
    btn.addEventListener("click", () => {
      const contato = JSON.parse(btn.dataset.contato);
      abrirModalEditar(contato);
    });
  });

  document.querySelectorAll(".deletar").forEach(btn => {
    btn.addEventListener("click", () => deletarContato(btn.dataset.id));
  });
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();

  const nome = nomeInput.value.trim();
  const telefone = telefoneInput.value.trim();
  const email = emailInput.value.trim();

  if (!nome || !telefone || !email) return alert("Preencha todos os campos!");

  await fetch("/api/contatos", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ nome, telefone, email })
  });

  form.reset();
  carregarContatos();
});

function abrirModalEditar(contato) {
  editandoId = contato.id;
  nomeEditar.value = contato.nome;
  telefoneEditar.value = contato.telefone;
  emailEditar.value = contato.email;
  modal.style.display = "block";
}

fecharModal.onclick = () => (modal.style.display = "none");
window.onclick = (event) => {
  if (event.target === modal) modal.style.display = "none";
};

formEditar.addEventListener("submit", async (e) => {
  e.preventDefault();

  await fetch(`/api/contatos/${editandoId}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      nome: nomeEditar.value,
      telefone: telefoneEditar.value,
      email: emailEditar.value
    })
  });

  modal.style.display = "none";
  carregarContatos();
});

async function deletarContato(id) {
  const confirmar = confirm("Tem certeza que deseja excluir este contato?");
  if (!confirmar) return;

  await fetch(`/api/contatos/${id}`, { method: "DELETE" });
  carregarContatos();
}

buscaInput.addEventListener("input", () => {
  const termo = buscaInput.value.toLowerCase();
  const filtrados = contatos.filter(c => c.nome.toLowerCase().includes(termo));
  renderizarTabela(filtrados);
});

carregarContatos();
