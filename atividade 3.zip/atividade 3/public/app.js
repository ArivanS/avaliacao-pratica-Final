// Dados iniciais de exemplo
let usuarios = [
    { id: 1, nome: "Maria Silva", email: "maria.silva@email.com", telefone: "(11) 99999-9999", status: "active" },
    { id: 2, nome: "João Santos", email: "joao.santos@email.com", telefone: "(21) 98888-8888", status: "active" },
    { id: 3, nome: "Ana Oliveira", email: "ana.oliveira@email.com", telefone: "(31) 97777-7777", status: "inactive" },
    { id: 4, nome: "Pedro Costa", email: "pedro.costa@email.com", telefone: "(41) 96666-6666", status: "active" }
];

// Elementos DOM
const formAdicionar = document.getElementById('form-adicionar');
const formEditar = document.getElementById('form-editar');
const tabelaUsuarios = document.getElementById('tabela-usuarios');
const buscaInput = document.getElementById('busca');
const modalEditar = document.getElementById('modal-editar');
const closeModalBtn = document.querySelector('.close-modal');
const emptyState = document.getElementById('empty-state');
const totalUsersElement = document.getElementById('total-users');
const activeUsersElement = document.getElementById('active-users');
const inactiveUsersElement = document.getElementById('inactive-users');

// Função para atualizar estatísticas
function atualizarEstatisticas() {
    const total = usuarios.length;
    const active = usuarios.filter(u => u.status === 'active').length;
    const inactive = total - active;
    
    totalUsersElement.textContent = total;
    activeUsersElement.textContent = active;
    inactiveUsersElement.textContent = inactive;
}

// Função para gerar avatar com iniciais
function gerarAvatar(nome) {
    const iniciais = nome.split(' ').map(n => n[0]).join('').toUpperCase();
    return `<div class="user-avatar">${iniciais.substring(0, 2)}</div>`;
}

// Função para renderizar a tabela
function renderizarTabela(usuariosFiltrados = usuarios) {
    tabelaUsuarios.innerHTML = '';
    
    if (usuariosFiltrados.length === 0) {
        emptyState.style.display = 'block';
        return;
    }
    
    emptyState.style.display = 'none';
    
    usuariosFiltrados.forEach(usuario => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>
                <div class="user-info">
                    ${gerarAvatar(usuario.nome)}
                    <div>
                        <div class="user-name">${usuario.nome}</div>
                        <div class="user-email">ID: ${usuario.id}</div>
                    </div>
                </div>
            </td>
            <td>${usuario.email}</td>
            <td>${usuario.telefone}</td>
            <td>
                <span class="status-badge ${usuario.status === 'active' ? 'status-active' : 'status-inactive'}">
                    ${usuario.status === 'active' ? 'Ativo' : 'Inativo'}
                </span>
            </td>
            <td>
                <div class="action-buttons">
                    <button class="action-btn edit-btn" data-id="${usuario.id}">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="action-btn delete-btn" data-id="${usuario.id}">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </td>
        `;
        tabelaUsuarios.appendChild(tr);
    });
    
    // Adicionar eventos aos botões
    document.querySelectorAll('.edit-btn').forEach(btn => {
        btn.addEventListener('click', () => abrirModalEditar(parseInt(btn.dataset.id)));
    });
    
    document.querySelectorAll('.delete-btn').forEach(btn => {
        btn.addEventListener('click', () => deletarUsuario(parseInt(btn.dataset.id)));
    });
    
    atualizarEstatisticas();
}

// Função para adicionar usuário
formAdicionar.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const nome = document.getElementById('nome').value;
    const email = document.getElementById('email').value;
    const telefone = document.getElementById('telefone').value;
    
    // Gerar ID único
    const novoId = usuarios.length > 0 ? Math.max(...usuarios.map(u => u.id)) + 1 : 1;
    
    // Adicionar usuário
    usuarios.push({
        id: novoId,
        nome,
        email,
        telefone,
        status: 'active'
    });
    
    // Limpar formulário
    formAdicionar.reset();
    
    // Renderizar tabela
    renderizarTabela();
    
    // Feedback visual
    const btn = formAdicionar.querySelector('button');
    const originalText = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-check"></i> Usuário Adicionado!';
    btn.style.background = '#4cc9f0';
    
    setTimeout(() => {
        btn.innerHTML = originalText;
        btn.style.background = '';
    }, 2000);
});

// Função para buscar usuários
buscaInput.addEventListener('input', () => {
    const termo = buscaInput.value.toLowerCase();
    
    if (termo.trim() === '') {
        renderizarTabela();
        return;
    }
    
    const usuariosFiltrados = usuarios.filter(usuario => 
        usuario.nome.toLowerCase().includes(termo) || 
        usuario.email.toLowerCase().includes(termo)
    );
    
    renderizarTabela(usuariosFiltrados);
});

// Função para abrir modal de edição
function abrirModalEditar(id) {
    const usuario = usuarios.find(u => u.id === id);
    
    if (!usuario) return;
    
    // Preencher formulário
    document.getElementById('edit-id').value = usuario.id;
    document.getElementById('edit-nome').value = usuario.nome;
    document.getElementById('edit-email').value = usuario.email;
    document.getElementById('edit-telefone').value = usuario.telefone;
    document.getElementById('edit-status').value = usuario.status;
    
    // Abrir modal
    modalEditar.classList.add('active');
}

// Função para fechar modal
function fecharModal() {
    modalEditar.classList.remove('active');
}

// Eventos para fechar modal
closeModalBtn.addEventListener('click', fecharModal);
modalEditar.addEventListener('click', (e) => {
    if (e.target === modalEditar) {
        fecharModal();
    }
});

// Função para salvar edição
formEditar.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const id = parseInt(document.getElementById('edit-id').value);
    const nome = document.getElementById('edit-nome').value;
    const email = document.getElementById('edit-email').value;
    const telefone = document.getElementById('edit-telefone').value;
    const status = document.getElementById('edit-status').value;
    
    // Atualizar usuário
    const index = usuarios.findIndex(u => u.id === id);
    
    if (index !== -1) {
        usuarios[index] = { ...usuarios[index], nome, email, telefone, status };
    }
    
    // Fechar modal e atualizar tabela
    fecharModal();
    renderizarTabela();
    
    // Feedback visual
    const btn = formEditar.querySelector('button');
    const originalText = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-check"></i> Alterações Salvas!';
    btn.style.background = '#4cc9f0';
    
    setTimeout(() => {
        btn.innerHTML = originalText;
        btn.style.background = '';
    }, 2000);
});

// Função para deletar usuário
function deletarUsuario(id) {
    if (confirm('Tem certeza que deseja excluir este usuário? Esta ação não pode ser desfeita.')) {
        usuarios = usuarios.filter(u => u.id !== id);
        renderizarTabela();
    }
}

// Inicializar
document.addEventListener('DOMContentLoaded', () => {
    renderizarTabela();
    atualizarEstatisticas();
});