const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./database.db', (err) => {
  if (err) console.error("Erro ao conectar ao banco:", err);
  else console.log("Conectado ao banco SQLite!");
});

db.run(`
  CREATE TABLE IF NOT EXISTS contatos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    telefone TEXT NOT NULL,
    email TEXT NOT NULL
  )
`);

module.exports = {
  listarTodos() {
    return new Promise((resolve, reject) => {
      db.all("SELECT * FROM contatos", [], (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  },

  buscarPorId(id) {
    return new Promise((resolve, reject) => {
      db.get("SELECT * FROM contatos WHERE id = ?", [id], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });
  },

  criar(nome, telefone, email) {
    return new Promise((resolve, reject) => {
      db.run(
        "INSERT INTO contatos (nome, telefone, email) VALUES (?, ?, ?)",
        [nome, telefone, email],
        function(err) {
          if (err) reject(err);
          else resolve({ id: this.lastID });
        }
      );
    });
  },

  atualizar(id, nome, telefone, email) {
    return new Promise((resolve, reject) => {
      db.run(
        "UPDATE contatos SET nome = ?, telefone = ?, email = ? WHERE id = ?",
        [nome, telefone, email, id],
        function(err) {
          if (err) reject(err);
          else resolve(this.changes > 0);
        }
      );
    });
  },

  deletar(id) {
    return new Promise((resolve, reject) => {
      db.run("DELETE FROM contatos WHERE id = ?", [id], function(err) {
        if (err) reject(err);
        else resolve(this.changes > 0);
      });
    });
  }
};
