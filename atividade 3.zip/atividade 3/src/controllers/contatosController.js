const Contato = require('../models/contatosModel');


module.exports = {
  async listar(req, res) {
    try {
      const contatos = await Contato.listarTodos();
      res.json(contatos);
    } catch (erro) {
      res.status(500).json({ erro: "Erro ao listar contatos" });
    }
  },

  async buscarPorId(req, res) {
    try {
      const id = req.params.id;
      const contato = await Contato.buscarPorId(id);
      if (!contato) return res.status(404).json({ erro: "Contato não encontrado" });
      res.json(contato);
    } catch (erro) {
      res.status(500).json({ erro: "Erro ao buscar contato" });
    }
  },

  async criar(req, res) {
    try {
      const { nome, telefone, email } = req.body;

      if (!nome || !telefone || !email)
        return res.status(400).json({ erro: "Todos os campos são obrigatórios" });

      const novo = await Contato.criar(nome, telefone, email);
      res.status(201).json({ mensagem: "Contato criado!", id: novo.id });
    } catch (erro) {
      res.status(500).json({ erro: "Erro ao criar contato" });
    }
  },

  async atualizar(req, res) {
    try {
      const id = req.params.id;
      const { nome, telefone, email } = req.body;

      const atualizado = await Contato.atualizar(id, nome, telefone, email);
      if (!atualizado) return res.status(404).json({ erro: "Contato não encontrado" });

      res.json({ mensagem: "Contato atualizado!" });
    } catch (erro) {
      res.status(500).json({ erro: "Erro ao atualizar contato" });
    }
  },

  async deletar(req, res) {
    try {
      const id = req.params.id;

      const deletado = await Contato.deletar(id);
      if (!deletado) return res.status(404).json({ erro: "Contato não encontrado" });

      res.json({ mensagem: "Contato deletado!" });
    } catch (erro) {
      res.status(500).json({ erro: "Erro ao deletar contato" });
    }
  }
};
