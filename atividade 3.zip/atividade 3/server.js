const express = require('express');
const app = express();
const path = require('path');

const contatosRoutes = require('./src/routes/contatosRoutes');


app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/api/contatos', contatosRoutes);

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});

process.on('uncaughtException', (err) => {
  console.error('Exceção não capturada:', err);
  process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Rejeição de promessa não tratada em:', promise, 'Razão:', reason);
});
